function execute() {
    return Response.success([
        {title: "Xiuren", input: "https://xiuren.biz/category/xiuren/", script: "gen.js"}
    ]);
}